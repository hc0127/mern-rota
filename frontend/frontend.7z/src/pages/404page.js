import React, { Component } from 'react';

export default class NotFound extends Component {
    render(){
        return(
            <>
                <h1 className='m-5'>404</h1>
                <span>Not Found</span>
            </>
        );
    }
}